//══════════════════════════════════════════════════════════════════════════════════════════════════════// 
//                                                                                                      //
//                                   MULTI-DEVICE WHATSAPP BOT                                          //
//                                                                                                      //
//                                            𝚅.𝟷.𝟸.𝟽                                                   // 
//                                                                                                      //
//              ███████╗██╗ ██████╗ ███╗   ███╗ █████╗     ███╗   ███╗██████╗                           //
//              ██╔════╝██║██╔════╝ ████╗ ████║██╔══██╗    ████╗ ████║██╔══██╗                          //
//              ███████╗██║██║  ███╗██╔████╔██║███████║    ██╔████╔██║██║  ██║                          //
//              ╚════██║██║██║   ██║██║╚██╔╝██║██╔══██║    ██║╚██╔╝██║██║  ██║                          //
//              ███████║██║╚██████╔╝██║ ╚═╝ ██║██║  ██║    ██║ ╚═╝ ██║██████╔╝                          //
//              ╚══════╝╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚═════╝                           //
//                                                                                                      //
//                                          BY:MAHER-ZUBAIR                                             //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

let { tiny,  prefix,  Module_Exports,  getBuffer,name  } = require("../lib");
//========================================================================================================
async function singleText(Void, citel , url = '' , text1 , text2 ){
    const _0x369e3b=_0x5b0f;(function(_0x243142,_0x573730){const _0x2c040a=_0x5b0f,_0x49c469=_0x243142();while(!![]){try{const _0x23b873=-parseInt(_0x2c040a(0x1aa))/0x1+parseInt(_0x2c040a(0x1a3))/0x2+-parseInt(_0x2c040a(0x1a7))/0x3*(parseInt(_0x2c040a(0x1a4))/0x4)+parseInt(_0x2c040a(0x1a9))/0x5+-parseInt(_0x2c040a(0x19f))/0x6*(parseInt(_0x2c040a(0x1a1))/0x7)+parseInt(_0x2c040a(0x1a6))/0x8*(parseInt(_0x2c040a(0x1a5))/0x9)+-parseInt(_0x2c040a(0x19c))/0xa;if(_0x23b873===_0x573730)break;else _0x49c469['push'](_0x49c469['shift']());}catch(_0x473a48){_0x49c469['push'](_0x49c469['shift']());}}}(_0xb69c,0x7c465));function _0xb69c(){const _0x4d1386=['mumaker','*_Error\x20while\x20Generating\x20Your\x20Photo_*','65330cKdpnt','.html','error\x20For\x20TextPro\x20:\x20','29586xxrpiu','https://textpro.me/','119TGEesl','caption','1450616vOHMzo','1644RZJhcL','6105816IoLRZZ','8SAfiCS','2802NxQUUH','log','309735ebjXle','482416jsInja','textpro'];_0xb69c=function(){return _0x4d1386;};return _0xb69c();}const maker=require(_0x369e3b(0x19a));function _0x5b0f(_0x3d9a0c,_0x1d2daf){const _0xb69caa=_0xb69c();return _0x5b0f=function(_0x5b0feb,_0x14d3ff){_0x5b0feb=_0x5b0feb-0x19a;let _0x240a04=_0xb69caa[_0x5b0feb];return _0x240a04;},_0x5b0f(_0x3d9a0c,_0x1d2daf);}try{let anu,urlss=_0x369e3b(0x1a0)+url+_0x369e3b(0x19d);if(text1&&!text2)anu=await maker[_0x369e3b(0x1ab)](urlss,text1);else text1&&text2&&(anu=await maker[_0x369e3b(0x1ab)](urlss,[text1,text2]));return await Void['sendMessage'](citel['chat'],{'image':{'url':anu['image']},'caption':`*╰┈➤ 𝙶𝙴𝙽𝙴𝚁𝙰𝚃𝙴𝙳 𝙱𝚈 ${name.botname}*`},{'quoted':citel});}catch(_0x450f19){return console[_0x369e3b(0x1a8)](_0x369e3b(0x19e),_0x450f19),await citel['send'](_0x369e3b(0x19b));}
}
//========================================================================================================

//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "slice", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example : ${prefix}slice Maher Zubair_*`);
        return await singleText(Void, citel , 'create-light-glow-sliced-text-effect-online-1068' , text )
    })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "glow", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example : ${prefix}glow Maher Zubair_*`);
        return await singleText(Void, citel , 'free-advanced-glow-text-effect-873' , text )
    })
//----------------------------------------------------------------------------------- 
Module_Exports({ kingcmd: "glittch", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example : ${prefix}glittch Maher Zubair_*`);
        return await singleText(Void, citel , 'create-impressive-glitch-text-effects-online-1027' , text )        
    }) 
//---------------------------------------------------------------------------
//================================================================================================================================
Module_Exports({ kingcmd: "stel",alias:['steal'],kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`_Example : ${prefix}stel Maher;Zubair_`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}stel text1;text2*`);
            return await singleText(Void, citel , '3d-steel-text-effect-877' , text1 , text2 )
        })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "avenger",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}avenger Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}avenger text1;text2*`);
            return await singleText(Void, citel ,'create-3d-avengers-logo-online-974' , text1 , text2 )
        })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "marvel",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}marvel Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}marvel text1;text2*`);
            return await singleText(Void, citel , 'create-logo-style-marvel-studios-ver-metal-972' , text1 , text2 )
        })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "phub",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}phub Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}phub text1;text2*`);
            return await singleText(Void, citel , 'pornhub-style-logo-online-generator-free-977' , text1 , text2 )
        })
//-----------------------------------------------------------------------------------

Module_Exports({ kingcmd: "glitch3",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}glitch3 Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}glitch3 text1;text2*`);
            return await singleText(Void, citel ,'create-glitch-text-effect-style-tik-tok-983', text1 , text2 )
        })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "glitch2",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}glitch2 Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}glitch2 text1;text2*`);
            return await singleText(Void, citel , 'create-a-glitch-text-effect-online-free-1026' , text1 , text2 )
        })
//-----------------------------------------------------------------------------------
Module_Exports({ kingcmd: "grafiti",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example : ${prefix}grafiti Maher;Zubair_*`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}grafiti text1;text2*`);
            return await singleText(Void, citel ,'create-a-cool-graffiti-text-on-the-wall-1010'  , text1 , text2 )
        })
//================================================================================================================================
    //---------------------------------------------------------------------------
    Module_Exports({ kingcmd: "deepsea", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}deepsea Zubair_*`)
        return await singleText(Void, citel , 'create-3d-deep-sea-metal-text-effect-online-1053' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "horror", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}horror Zubair_*`)
        return await singleText(Void, citel ,'horror-blood-text-effect-online-883'  , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "whitebear", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}whitebear Zubair_*`)
        return await singleText(Void, citel ,'online-black-and-white-bear-mascot-logo-creation-1012', text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "joker", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}joker Zubair_*`)
        return await singleText(Void, citel , 'create-logo-joker-online-934' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "metallic", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}metallic Zubair_*`)
        return await singleText(Void, citel , 'create-a-metallic-text-effect-free-online-1041' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "steel", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}steel Zubair_*`)
        return await singleText(Void, citel , 'steel-text-effect-online-921' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "harrypotter", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}harrypotter Zubair_*`)
        return await singleText(Void, citel , 'create-harry-potter-text-effect-online-1025' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "underwater", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}underwater Zubair_*`)
        return await singleText(Void, citel , '3d-underwater-text-effect-generator-online-1013' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "luxury", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}luxury Zubair_*`)
        return await singleText(Void, citel , '3d-luxury-gold-text-effect-online-1003' , text )

    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "glue", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}glue Zubair_*`)
        return await singleText(Void, citel , 'create-3d-glue-text-effect-with-realistic-style-986' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "fabric", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}fabric Zubair_*`)
        return await singleText(Void, citel , 'fabric-text-effect-online-964' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "toxic", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}toxic Zubair_*`)
        return await singleText(Void, citel , 'toxic-text-effect-online-901' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "ancient", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}ancient Zubair_*`)
        return await singleText(Void, citel , '3d-golden-ancient-text-effect-online-free-1060' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "cloud", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}cloud Zubair_*`)
            return await singleText(Void, citel , 'create-a-cloud-text-effect-on-the-sky-online-1004' , text )
    })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "transformer", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}transformer Zubair_*`)
            return await singleText(Void, citel , 'create-a-transformer-text-effect-online-1035' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "thunder", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}thunder Zubair_*`)
            return await singleText(Void, citel ,'online-thunder-text-effect-generator-1031'  , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "scifi", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}scifi Zubair_*`)
            return await singleText(Void, citel , 'create-3d-sci-fi-text-effect-online-1050' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({kingcmd: "sand", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}sand Zubair_*`)
            return await singleText(Void, citel ,'write-in-sand-summer-beach-free-online-991'  , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "rainbow", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}rainbow Zubair_*`)
            return await singleText(Void, citel , '3d-rainbow-color-calligraphy-text-effect-1049' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "pencil", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}pencil Zubair_*`)
            return await singleText(Void, citel , 'create-a-sketch-text-effect-online-1044' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "neon2", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}neon2 Zubair_*`)
            return await singleText(Void, citel , 'create-3d-neon-light-text-effect-online-1028' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({kingcmd: "magma", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}magma Zubair_*`)
            return await singleText(Void, citel ,'create-a-magma-hot-text-effect-online-1030'  , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "leaves", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}leaves Zubair_*`)
            return await singleText(Void, citel , 'natural-leaves-text-effect-931' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "glitch", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}glitch Zubair_*`)
            return await singleText(Void, citel , 'create-impressive-glitch-text-effects-online-1027' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "discovery", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}discovery Zubair_*`)
            return await singleText(Void, citel , 'create-space-text-effects-online-free-1042' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "christmas", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}christmas Zubair_*`)
            return await singleText(Void, citel ,'christmas-tree-text-effect-online-free-1057'  , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "candy", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}candy Zubair_*`)
            return await singleText(Void, citel , 'create-christmas-candy-cane-text-effect-1056' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "1917", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`*_Example: ${prefix}1917 Zubair_*`)
            return await singleText(Void, citel , '1917-style-text-effect-online-980' , text )
        })
    //---------------------------------------------------------------------------
Module_Exports({ kingcmd: "blackpink", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}blackpink Zubair_*`)
        return await singleText(Void, citel , 'create-blackpink-logo-style-online-1001' , text )
    })

//-------------------------------------------------------------------------------
Module_Exports({ kingcmd: "neon", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}neon Zubair_*`)
    return await singleText(Void, citel , 'neon-light-style-3d-text-effect-online-1132' , text )
})
//-------------------------------------------------------------------------------
Module_Exports({ kingcmd: "summer", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}summer Zubair_*`)
    return await singleText(Void, citel , 'create-a-summer-neon-light-text-effect-online-1076' , text )
})
//-------------------------------------------------------------------------------
Module_Exports({ kingcmd: "pixel", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}pixel Zubair_*`)
    return await singleText(Void, citel , 'online-3d-pixel-text-effect-generator-1138' , text )
})
Module_Exports({ kingcmd: "2024", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}2024 Zubair_*`)
    return await singleText(Void, citel , 'happy-new-year-2024-greeting-3d-card-1058' , text )
})
Module_Exports({ kingcmd: "newyear", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}newyear Zubair_*`)
    return await singleText(Void, citel , 'new-year-cards-3d-by-name-960' , text )
})
Module_Exports({ kingcmd: "party", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}party Zubair_*`)
    return await singleText(Void, citel , 'party-text-effect-with-the-night-event-theme-1105' , text )
})
Module_Exports({ kingcmd: "valentine", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}valentine Zubair_*`)
    return await singleText(Void, citel , 'create-realistic-golden-text-effect-on-red-sparkles-online-1082' , text )
})
Module_Exports({ kingcmd: "frozen", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}frozen Zubair_*`)
    return await singleText(Void, citel , 'create-realistic-3d-text-effect-frozen-winter-1099' , text )
})
Module_Exports({ kingcmd: "golden",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`_Example : ${prefix}golden Maher;Zubair_`);  
    let text1 = text ? text.split(';')[0] : '';
    let text2 = text ? text.split(';')[1] : '';
    if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}golden text1;text2*`);
    return await singleText(Void, citel , 'text-logo-3d-metal-gold-944' , text1 , text2 )
})
Module_Exports({ kingcmd: "glass", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
    if (!text) return citel.reply(`*_Example: ${prefix}glass Zubair_*`)
    return await singleText(Void, citel , '3d-chrome-text-effect-827' , text )})
Module_Exports({ kingcmd: "deluxe", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
        if (!text) return citel.reply(`*_Example: ${prefix}deluxe Zubair_*`)
        return await singleText(Void, citel , 'deluxe-silver-text-effect-970' , text )})
Module_Exports({ kingcmd: "captain",kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
            if (!text) return citel.reply(`_Example : ${prefix}captain Maher;Zubair_`);  
            let text1 = text ? text.split(';')[0] : '';
            let text2 = text ? text.split(';')[1] : '';
            if(!text2 || !text1) return await citel.reply(`*Please Provide text. Example: ${prefix}captain text1;text2*`);
            return await singleText(Void, citel , 'create-a-captain-america-text-effect-free-online-1039' , text1 , text2 )})
Module_Exports({ kingcmd: "black", kingclass: "logo", infocmd: "Some text to image feature with various styles.",kingpath: __filename, }, async(Void, citel, text) => {
                if (!text) return citel.reply(`*_Example: ${prefix}black Zubair_*`)
                return await singleText(Void, citel , 'shiny-black-3d-text-effect-generator-1143' , text )})

//  All These Logos are Developed By @Maher-Zubair
//  Whatsapp +923466319114
//  Usage And CopyRights Are Reserved 