
<h1 align="center"> sɪɢᴍᴀ ᴹᴰ </h1>
</p>
<p align="center">
  <a href="https://www.youtube.com/@InnoxentTech">
    <img alt=Support height="350" src="https://telegra.ph/file/03e49e6e2057568db8926.jpg"> 
    </p>
    <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Playfair+Display&weight=500&size=34&duration=3500&pause=1000&color=F7F7F7&center=true&width=435&lines=Welcome+To+SIGMA-MD;Multi-Device+Whatsapp+Bot;Developed+By+Maher+Zubair;Released+Date+1%2F10%2F2023." alt="Typing SVG" /></a>
  </p>

<p align="center">
  <a href="https://github.com/Maher-Zubair/SIGMA-MD/fork">
    <img src="https://img.shields.io/github/forks/Maher-Zubair/SIGMA-MD?label=Fork&style=social">
    
    
  <a href="https://github.com/Maher-Zubair/SIGMA-MD/stargazers"> 
    <img src="https://img.shields.io/github/stars/Maher-Zubair?style=social">
  </a>

</p>


<p align="center">
<a href="https://github.com/Maher-Zubair"><img title="Owner" src="https://img.shields.io/badge/Owner-Maher Zubair-black.svg?style=for-the-badge&logo=github" width="173px" height="29"></a>

 <a href="https://github.com/Maher-Zubair/SIGMA-MD/blob/main/LICENCE">
<img src='https://img.shields.io/github/license/Maher-Zubair/SIGMA-MD?color=%231e81b0&style=for-the-badge' width="143px">
<p align="center"> 
  <a aria-label="Join our chats" href="https://chat.whatsapp.com/CmY0THcJCUYEGxLJulhcRV" target="_blank">
   <img alt="whatsapp" src="https://img.shields.io/badge/Support Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
    <a aria-label="Join our chats" href="https://chat.whatsapp.com/KFe2GEMBZ9eI1bpNVotZOW" target="_blank">
   <img alt="whatsapp" src="https://img.shields.io/badge/Public Bot Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

<p align="center"><img src="https://profile-counter.glitch.me/{Maher-Zubair}/count.svg" alt="Maher-Zubair :: Visitor's Count" /></p>

## ***Bot Features***
---
1. ***Game Menu.***
2.  ***Multi-Themes Supported.***
3.  ***Huge Logo Maker Menu.***
4. ***Group Management Commands.***
5.  ***Photo Editor Menu.***
6.  ***Ban Protection.***
7.  ***Multi-Device Supported.***
8.  ***350+ Commands.***
##






## `𝘋𝘦𝘱𝘭𝘰𝘺𝘮𝘦𝘯𝘵 𝘔𝘦𝘵𝘩𝘰𝘥𝘴`
1. ***Star⭐ The Repository First***
2. ***Click [`FORK`](https://github.com/Maher-Zubair/SIGMA-MD/fork)***
3. ***Get SESSION ID  by [`Scanning QR Code`](https://replit.com/@Mehar-Zubair/SIGMA-MD?v=1). `Whatapp>Three dots>Linked Devices`***
4. ***Get a Mongodb url From [`Mongodb,`](https://account.mongodb.com/)  Watch Tutorial  [`How To Get MongoDB Url`](https://youtu.be/HNj76uDT-uc?si=ObIoNZoP5gSZ8bSF).***
5. ***Deploy on [`Heroku,`](https://mkk-eta.vercel.app/heroku.html)  Watch Tutorial 
 [`How To Deploy on Heroku`](https://youtu.be/7hhuzIkhVfE).***
6. ***Deploy FREE on `Codespace,`  Watch Tutorial  [`How To Deploy on Codespace`](https://youtu.be/q59Fyn0Dq_k)***
7. ***Deploy on [`Replit,`](https://replit.com/github/Maher-Zubair/SIGMA-MD)  Watch Tutorial  [`How To Deploy on Replit`](https://youtu.be/Ax4nO5PIHFA).***
8. ***Install [`External Plugins`](https://github.com/Maher-Zubair/SIGMA-MD_Plugins).***
##

- ***If You Don't Have Any MongoDB Url Then, Use This Public one.!***
```
mongodb+srv://Maher-Zubair:SIGMA-MD@zubi.9g6b16y.mongodb.net/?retryWrites=true&w=majority&appName=AtlasApp
```
- *I will Recommend You To Use Your own MongoDB Key So That You Will Not Face any Issue, Watch Tutorial  [`How To Get MongoDB Url`](https://youtu.be/HNj76uDT-uc?si=ObIoNZoP5gSZ8bSF).*
##

***Subscribe MY YouTube Channel***
</p>
<p align="left">
  <a href="https://www.youtube.com/@InnoxentTech?sub_confirmation=1">
    <img alt=Support height="90" src="https://telegra.ph/file/eb6347e2764939fbbd35d.png"> 
  </p>
    
 ## ```𝘛𝘢𝘱 𝘈𝘯𝘺 𝘓𝘖𝘎𝘖 𝘛𝘰 𝘊𝘰𝘯𝘵𝘢𝘤𝘵 𝘔𝘦```
 <p align="centre">
  <a href="mailto:HELP_SIGMA-MD@outlook.com">
    <img src="https://i.ibb.co/Kx8NXxT/mail-gmail-22737.png" align="centre" width="90" />
   <a href="https://wa.me/923466319114?text=Hi%20Maher-Zubair%20Sir...%20I%20need%20some%20help%20in%20SIGMA-MD">
    <img src="https://i.ibb.co/2MLVZwm/whatsapp-logo-icon-181644.png" align="centre" width="90" />

##

- ***Star ⭐ My Repo If You Like This Bot.***

- ***The [SIGMA-MD](https://github.com/Maher-Zubair/SIGMA-MD) is Made Under The [`GPL-3 license`](https://github.com/Maher-Zubair/SIGMA-MD/blob/main/LICENCE).***

### `𝘚𝘱𝘦𝘤𝘪𝘢𝘭 𝘛𝘩𝘢𝘯𝘬𝘴 𝘛𝘰`
- ***[Suhail Tech Info](https://github.com/SuhailTechInfo)***
- ***[Diegoson Tech](https://github.com/DiegosonTech)***
- ***[Sam Pandey](https://github.com/SamPandey001)***
##
## ```𝘓𝘦𝘨𝘢𝘭 𝘋𝘪𝘴𝘤𝘭𝘢𝘪𝘮𝘦𝘳```
- *I will only Assist You in Bot Deployment and Hosting, Not in Bot Development*
- *If You Modify The Bot And Face Any Issue, I will not Responsible Because It is not Possible For Me To Help Everyone*
- *This Bot is For Fun and Educational Purpose, I will not Responsible If You Spam and Misuse It*
- ***Regards [Maher-Zubair](https://github.com/Maher-Zubair)***
